class Appliance:
    def __init__(self, name, power, hours):
        self.name = name
        self.power = power
        self.hours = hours

    def daily_consumption(self):
        return self.power * self.hours / 1000