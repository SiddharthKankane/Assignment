from appl import Appliance
from dailycost import Calculator

def main():
    ac = Appliance("ac", 1250, 24)

    appliances = [ac]

    cost_per_unit = 10

    calculator = Calculator(appliances, cost_per_unit)

    print(f"Total daily consumption: {calculator.total_daily_consumption()} kWh")
    print(f"Total daily cost: {calculator.total_daily_cost()} currency units")

if __name__ == "__main__":
    main()