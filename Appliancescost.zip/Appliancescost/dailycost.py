from appl import Appliance as app

class Calculator:
    def __init__(self, appliances, cost):
        self.appliances = appliances
        self.cost = cost

    def total_daily_consumption(self):
        return sum(app.daily_consumption() for app in self.appliances)

    def total_daily_cost(self):
        return self.total_daily_consumption() * self.cost